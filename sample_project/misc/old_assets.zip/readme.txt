Old assets backup from the previous website version.
